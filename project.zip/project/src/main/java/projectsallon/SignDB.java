package projectsallon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class SignDB {
	public static Connection getConnection(){  
        Connection con=null;  
        try{    
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salon","root","Keerthivasan@22");  
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }  
        return con;  
    }
	public static int save(Signup s )
	{
		int status=0;
		try
		{
			Connection con=SignDB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into signup values(?,?,?)");
			ps.setString(1,s.getName());
			ps.setString(2,s.getEmail());
			ps.setString(3,s.getPassword());
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}

}
