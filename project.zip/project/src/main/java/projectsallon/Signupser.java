package projectsallon;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Signupser
 */
@WebServlet("/Signupser")
public class Signupser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signupser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String sign_name=request.getParameter("sName");
		String signup_email=request.getParameter("semail");
		String signup_password=request.getParameter("spassword");
		Signup s=new Signup();
		s.setEmail(signup_email);
		s.setName(sign_name);
		s.setPassword(signup_password);
		int result=SignDB.save(s);
		PrintWriter pw = response.getWriter();


		if(result>0){  
        	pw.write("<script>alert('Successfully Registered You can Login Now')</script>"); 
            request.getRequestDispatcher("login.jsp").include(request, response);  
        }else{  
        	pw.write("<script>alert('Not Regitered Try again')</script>");
			pw.write("<script>window.location='signup.jsp'</script>");
            pw.println("Sorry! unable to save record");  
        } 
	}

}
