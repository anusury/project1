package projectsallon;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.lang.*;
public class CusDB {
	public static Connection getConnection(){  
        Connection con=null;  
        try{    
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salon","root","Keerthivasan@22");  
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }  
        return con;  
    }
	public static int save(Customer c )
	{
		int status=0;
		try
		{
			Connection con=CusDB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into customers(name,phone_no,mail_id,gender,style,booking_time) values(?,?,?,?,?,?)");
			ps.setString(1,c.getname());
			ps.setString(2,c.getphno());
			ps.setString(3,c.getemail());
			ps.setString(4,c.getgender());
			ps.setString(5,c.getstyle());
			ps.setString(6,c.getbookingtime());
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
	 public static List<Customer> getAllCustomers(){  
	        List<Customer> list=new ArrayList<Customer>();  
	          
	        try{  
	            Connection con=CusDB.getConnection();  
	            PreparedStatement ps=con.prepareStatement("select * from customers");  
	            ResultSet rs=ps.executeQuery();  
	            while(rs.next()){  
	                Customer e=new Customer();  
	                e.setid(rs.getInt(1)); 
	                e.setname(rs.getString(2));  
	                e.setphno(rs.getString(3));  
	                e.setemail(rs.getString(4));  
	                e.setgender(rs.getString(5));
	                e.setstyle(rs.getString(6));
	                e.setbookingtime(rs.getString(7));
	                list.add(e);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  

}
