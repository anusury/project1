package projectsallon;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.println("<h1>Booking List</h1>"); 
        List<Customer>list=CusDB.getAllCustomers();
        out.print("<table border='1' width='100%'");  
        out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Gender</th><th>Phone Number</th><th>Style</th><th>Booking Date and Time</th></tr>");  
        for(Customer e:list){  
         out.print("<tr><td>"+e.getid()+"</td><td>"+e.getname()+"</td><td>"+e.getemail()+"</td><td>"+e.getgender()+"</td><td>"+e.getphno()+"</td><td>"+e.getstyle()+ "</td><td>"+e.getbookingtime());  
        }  
        out.print("</table>");  
        out.close();  

        
	}

}
