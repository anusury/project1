package projectsallon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginCK {
	public static Connection getConnection(){  
        Connection con=null;  
        try{    
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salon","root","Keerthivasan@22");  
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }  
        return con;  
    }
	public static boolean check(Login l )
	{
		try
		{
			Connection con=LoginCK.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from signup where email=? and password=?");
			ps.setString(1, l.getLemail());
			ps.setString(2, l.getLpassword());
			ResultSet set = ps.executeQuery();
			int count=0;
			while(set.next()) {
			count=1;
			}
			con.close();
			if(count==1) {
			return true;
			}
			else
			{
			return false;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
		
	}
	
}
