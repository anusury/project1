package projectsallon;

import java.time.LocalDateTime;

public class Customer {
	private int id;
	private String name,phno,email,style,gender;
	String bookingtime;
	public void setid(int id)
	{
		this.id=id;

	}
	public int getid()
	{
		return id;
	}
	public void setname(String name)
	{
		this.name=name;
		
	}
	public String getname()
	{
		return name;
	}
	public void setphno(String phno)
	{
		this.phno=phno;
		
	}
	public String getphno()
	{
		return phno;
	}
	public void setemail(String email)
	{
		this.email=email;
		
	}
	public String getemail()
	{
		return email;
	}
	public void setgender(String gender)
	{
		this.gender=gender;
		
	}
	public String getgender()
	{
		return gender;
	}
	public void setstyle(String style)
	{
		this.style=style;
		
	}
	public String getstyle()
	{
		return style;
	}
	public void setbookingtime(String timestamp)
	{
		this.bookingtime=timestamp;
		
	}
	public String getbookingtime()
	{
		return bookingtime;
	}
}
