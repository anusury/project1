package projectsallon;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginDB
 */
@WebServlet("/LoginDB")
public class LoginDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginDB() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String login_email=request.getParameter("lemail");
		String login_password=request.getParameter("lpassword");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Login l=new Login();
		l.setLemail(login_email);
		l.setLpassword(login_password);
		boolean checker=LoginCK.check(l);
		boolean b1=true;
		if(login_email.equals("admin@gmail.com") &&login_password.equals("keerthi") )
		{
			pw.write("<script>alert('*****Welcome Admin******')</script>");
            request.getRequestDispatcher("admin.jsp").include(request, response);  
		}
		else if(checker ==b1)
		{
			pw.write("<script>alert('*****Welcome You can Book Your slot*****')</script>");
            request.getRequestDispatcher("booking.jsp").include(request, response);  

		}
		else
		{
			pw.write("<script>alert('inavid email or password.')</script>");
			pw.write("<script>window.location='login.jsp'</script>");

		}
	}

}
