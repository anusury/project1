package projectsallon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Dbmain
 */
@WebServlet("/Dbmain")
public class Dbmain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Dbmain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String gender=request.getParameter("gender");
		String name=request.getParameter("Name");
		String phno=request.getParameter("tel");
		String email=request.getParameter("email");
		String style=request.getParameter("style");
		String bookingtime=request.getParameter("bookingtime");
				
		//			pw.write(radio);
//			pw.write(name);
//			pw.write(phno);
//			pw.write(email);
//			pw.write(style);
//			pw.write("<br>");
//			pw.write(bookingtime);
		
		
		Customer c=new Customer();
		c.setname(name);
		c.setphno(phno);
		c.setemail(email);
		c.setgender(gender);
		c.setstyle(style);
		c.setbookingtime(bookingtime);
		int status=CusDB.save(c);
		if(status>0){    
            request.getRequestDispatcher("login.jsp").include(request, response);  
        }else{  
            pw.println("Sorry! unable to save record");  
        } 
		
		
		
		
	}

}
